

-- 1. KHỞI TẠO CƠ SỞ DỮ LIỆU

DROP DATABASE IF EXISTS university_db;
CREATE DATABASE university_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE university_db;

DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS instructors;
DROP TABLE IF EXISTS semesters;
DROP TABLE IF EXISTS departments;


-- CONSTRAINTS


-- B1: departments
CREATE TABLE departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- B2: semesters
CREATE TABLE semesters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(50) NOT NULL,
    academic_year INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    CONSTRAINT chk_semester_dates CHECK (end_date > start_date)
) ENGINE=InnoDB;

-- B3: instructors
CREATE TABLE instructors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_code VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NULL,
    department_id INT NOT NULL,
    CONSTRAINT fk_instructors_departments 
        FOREIGN KEY (department_id) REFERENCES departments(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- B4: students
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_code VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    gender ENUM('Nam', 'Nữ', 'Khác') NOT NULL DEFAULT 'Nam',
    birth_date DATE NOT NULL,
    gpa DECIMAL(3,2) DEFAULT 0.00,
    department_id INT NOT NULL,
    CONSTRAINT chk_student_gpa CHECK (gpa >= 0.00 AND gpa <= 4.00),
    CONSTRAINT fk_students_departments 
        FOREIGN KEY (department_id) REFERENCES departments(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- B5: courses
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    credits INT NOT NULL DEFAULT 3,
    description TEXT NULL,
    department_id INT NOT NULL,
    instructor_id INT NOT NULL,
    CONSTRAINT chk_course_credits CHECK (credits > 0),
    CONSTRAINT fk_courses_departments 
        FOREIGN KEY (department_id) REFERENCES departments(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_courses_instructors 
        FOREIGN KEY (instructor_id) REFERENCES instructors(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- B6:enrollments
CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester_id INT NOT NULL,
    grade DECIMAL(3,2) NULL,
    status ENUM('Đã đăng ký', 'Đã hoàn thành', 'Đã hủy') NOT NULL DEFAULT 'Đã đăng ký',
    enrolled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_enrollment UNIQUE (student_id, course_id, semester_id),
    CONSTRAINT chk_enrollment_grade CHECK (grade IS NULL OR (grade >= 0.00 AND grade <= 4.00)),
    CONSTRAINT fk_enrollments_students 
        FOREIGN KEY (student_id) REFERENCES students(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_courses 
        FOREIGN KEY (course_id) REFERENCES courses(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_semesters 
        FOREIGN KEY (semester_id) REFERENCES semesters(id) 
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- SAMPLE DATA)


INSERT INTO departments (code, name, description) VALUES
('IT', 'Khoa Công nghệ Thông tin', 'Chuyên đào tạo kỹ sư phần mềm, khoa học máy tính và hệ thống thông tin'),
('BA', 'Khoa Quản trị Kinh doanh', 'Chuyên đào tạo quản trị doanh nghiệp, marketing và phân tích kinh doanh'),
('FIN', 'Khoa Tài chính - Ngân hàng', 'Chuyên đào tạo tài chính doanh nghiệp, đầu tư và ngân hàng'),
('ENG', 'Khoa Ngoại ngữ', 'Chuyên đào tạo ngôn ngữ Anh và tiếng Anh thương mại'),
('NET', 'Khoa Mạng máy tính & Truyền thông', 'Chuyên đào tạo an toàn thông tin và điện toán đám mây');

INSERT INTO semesters (code, name, academic_year, start_date, end_date) VALUES
('FALL2024', 'Học kỳ Thu 2024', 2024, '2024-09-01', '2024-12-31'),
('SPRING2025', 'Học kỳ Xuân 2025', 2025, '2025-01-15', '2025-05-15'),
('SUMMER2025', 'Học kỳ Hè 2025', 2025, '2025-06-01', '2025-08-15'),
('FALL2025', 'Học kỳ Thu 2025', 2025, '2025-09-01', '2025-12-31'),
('SPRING2026', 'Học kỳ Xuân 2026', 2026, '2026-01-15', '2026-05-15');

INSERT INTO instructors (instructor_code, full_name, email, phone, department_id) VALUES
('GV001', 'Nguyễn Văn An', 'an.nguyen@university.edu.vn', '0901234567', 1),
('GV002', 'Trần Thị Bích', 'bich.tran@university.edu.vn', '0912345678', 2),
('GV003', 'Lê Hoàng Nam', 'nam.le@university.edu.vn', '0923456789', 3),
('GV004', 'Phạm Minh Đức', 'duc.pham@university.edu.vn', '0934567890', 4),
('GV005', 'Đỗ Thị Mai', 'mai.do@university.edu.vn', '0945678901', 5);

INSERT INTO students (student_code, full_name, email, gender, birth_date, gpa, department_id) VALUES
('SV202401', 'Hoàng Văn Cường', 'cuong.hv@student.edu.vn', 'Nam', '2004-03-15', 3.45, 1),
('SV202402', 'Nguyễn Thị Duyên', 'duyen.nt@student.edu.vn', 'Nữ', '2004-07-22', 3.80, 2),
('SV202403', 'Trịnh Quốc Anh', 'anh.tq@student.edu.vn', 'Nam', '2003-11-05', 2.95, 3),
('SV202404', 'Vũ Minh Thu', 'thu.vm@student.edu.vn', 'Nữ', '2004-01-30', 3.60, 4),
('SV202405', 'Lê Thanh Tùng', 'tung.lt@student.edu.vn', 'Nam', '2004-09-12', 3.10, 5);

INSERT INTO courses (course_code, title, credits, description, department_id, instructor_id) VALUES
('INS3064', 'Hệ quản trị Cơ sở dữ liệu', 3, 'Thiết kế cơ sở dữ liệu quan hệ, SQL và tối ưu hóa truy vấn', 1, 1),
('MGT1001', 'Quản trị học đại cương', 3, 'Cung cấp kiến thức nền tảng về tổ chức và quản lý doanh nghiệp', 2, 2),
('FIN2002', 'Tài chính doanh nghiệp', 4, 'Phân tích báo cáo tài chính, quản lý vốn và kế hoạch tài chính', 3, 3),
('ENG1002', 'Tiếng Anh chuyên ngành IT', 2, 'Phát triển từ vựng và thuật ngữ chuyên ngành công nghệ thông tin', 4, 4),
('NET3001', 'Mạng máy tính nâng cao', 3, 'Thiết kế hệ thống mạng, định tuyến và cấu hình thiết bị', 5, 5);

INSERT INTO enrollments (student_id, course_id, semester_id, grade, status) VALUES
(1, 1, 1, 3.70, 'Đã hoàn thành'),
(1, 4, 1, 3.50, 'Đã hoàn thành'),
(2, 2, 1, 4.00, 'Đã hoàn thành'),
(2, 4, 1, 3.60, 'Đã hoàn thành'),
(3, 3, 1, 2.80, 'Đã hoàn thành'),
(4, 4, 2, 3.80, 'Đã hoàn thành'),
(5, 5, 2, 3.20, 'Đã hoàn thành'),
(1, 5, 2, NULL, 'Đã đăng ký'),
(3, 1, 2, NULL, 'Đã đăng ký'),
(5, 1, 2, NULL, 'Đã đăng ký');

-- RESULT GRID)

SELECT * FROM departments;
SELECT * FROM semesters;
SELECT * FROM instructors;
SELECT * FROM students;
SELECT * FROM courses;
SELECT * FROM enrollments;